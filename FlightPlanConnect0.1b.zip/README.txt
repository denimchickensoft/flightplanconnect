  ___ _    ___ ___ _  _ _____       
 | __| |  |_ _/ __| || |_   _|      
 | _|| |__ | | (_ | __ | | |        
 |_|_|____|___\___|_||_| |_|        
 | _ \ |    /_\ | \| |              
 |  _/ |__ / _ \| .` |              
 |_|_|____/_/ \_\_|\_|___ ___ _____ 
  / __/ _ \| \| | \| | __/ __|_   _|
 | (_| (_) | .` | .` | _| (__  | |  
  \___\___/|_|\_|_|\_|___\___| |_|v0.1

Flight Plan Connect v0.1 ©2020 DenimChickenSoft

===========
Description
===========
FlightPlanConnect (FPC) is an FSX/ATC Client tool.  It facilitates communication between FSX and VRC/EuroScope, without the need for an FSD server, by utilizing the FSX SimConnect SDK.

This allows you to view and control traffic much as you would on an FSD server such as VATSIM or IVAO. 

It is also able to sync the ATC Client with flight plans on fsATC's strips page, courtesy of Kermout (thanks Kermie).  This is currently a one-way street.  It will only update the ATC Client's flight plan information for matching TAIL NUMBERS, i.e. the Tail Number matches the fsATC strip's callsign.  It will not sync fsATC strips with information you change in your ATC Client.

It is an x86 (not x64) application due to having to interface with FSX SimConnect.

============
Requirements
============
-Microsoft FlightSimulator X
-VRC or EuroScope
-SimConnect dll (Now included in zip. No installation required!)
-Microsoft .NET 4.8+

============
Installation
============
-Unzip all files to the same folder. (important)
-Doubleclick on RUNFIRST.bat. (Creates myservers.txt & fsATC VRC profile)
-Doubleclick FlightPlanConnect.exe

============
Instructions
============
1) Open FSX, ATC Client (VRC or EuroScope), and FlightPlanConnect.
2) In FSX, connect to a multiplayer session.
3) Press the "Connect" button on FPC.
4) In the ATC Client, open the connect dialog. (VRC -> File:Connect...) (EuroScope -> Connect button)
5) Ensure Callsign matches your intended ICAO position!  For example KJFK_TWR, EHAM_GND, EGLL_TWR, etc.  This is mainly for auto-METAR functions, but may affect functionality in the future.
6) For VRC, ensure Rating is greater than Observer.  Select Admin if you want.  You've earned it! ;D
7) Real Name, Facility, Certificate, and Password are irrelevant (for now), but must be filled out. 
8) ¡Server must be localhost!  For EuroScope, just type "localhost".  For VRC, create "myservers.txt" in the VRC home folder with first line "localhost localhost" in order to be able to select it from the dropdown menu.
9) For EuroScope, Connect to VATSIM checkbox must be checked.  This seems counterintutive, but there's a reason for it.
10) Click Connect!
11) Click "Sync Plans" to sync fsATC flight plans with ATC clients.

========
Features
========
-Aircraft tail number (callsign), position, altitude, speed, & squawk updates.
-METAR availability for any airport! (F2 + 4 letter ICAO + Enter or try ".QD KJFK")
-basic fsATC strips syncing!
-"Mode C" interrogator mode - treats aircraft squawking 1200 as if they were squawking Standby

============
Version Info
============
Last bug fix: Flight plan uplink

============
Known Issues
============
-During some disconnects you may receive some exceptions in the Console/Debug window.  This is expected.  It should not crash the program or affect functionality.  Usually.
-During some shaky multiplayer server connections, you may get issues with aircraft position reporting.
-Many ATC Client functions are not usable, as they were designed around VATSIM.  There is no current provision for controller coordination or voice, for example.

===============
Troubleshooting
===============
-Ensure that Microsoft .NET Framework 4.8+ is installed.
-Ensure that the FSX SDK is installed.

=======
Contact
=======
denimchickensoft@gmail.com (gimme your bugs, yo)

======
Thanks
======
-Kermout (developer of fsATC strips page)
-ATC Roo (developer of ESJFS)

==========
Disclaimer
==========
All third party trademarks (including logos and icons) referenced by DenimChickenSoft ("DCS") remain the property of their respective owners. Unless specifically identified as such, DCS use of third party trademarks does not indicate any relationship, sponsorship, or endorsement between DCS and the owners of these trademarks. Any references by DCS to third party trademarks is to identify the corresponding third party goods and/or services and shall be considered nominative fair use under the trademark law.